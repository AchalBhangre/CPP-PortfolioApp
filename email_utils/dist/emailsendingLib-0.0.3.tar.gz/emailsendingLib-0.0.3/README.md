# CPP-PortfolioApp



cd ..
  418  git push -f origin main
  419  git remote set-url origin https://github.com/AchalBhangre/CPP-PortfolioApp.git
  420  git push -f origin main
  421  git remote add origin https://github.com/AchalBhangre/CPP-PortfolioApp.git
  422  git sttaus
  423  git status
  424  git branch -m main
  425  git push -f origin main
  426  history

from django.contrib import admin
from .models import PortfolioRegistration,PortfolioImage
# Register your models here.

admin.site.register(PortfolioRegistration)
admin.site.register(PortfolioImage)